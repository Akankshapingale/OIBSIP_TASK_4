package online_exam;
//Akanksha Shivaji Pingale
//Task 4:Online Examination

import java.io.*;
import java.util.*;
public class online_exam 
{
HashMap<String,Integer> data=new HashMap<String,Integer>();
Scanner s1=new Scanner(System.in);
	public void login() 
	{
		data.put("Akanksha",41240);
		data.put("Akash",12345);
		System.out.println("\n**********Welcome to online exam portal**********");
		String user_id;
		int Password;
		System.out.println("------------Login------------");
		System.out.print("Enter user id: ");
		user_id=s1.next();
		System.out.print("Enter password: ");
		Password=s1.nextInt();
		if(data.containsKey(user_id) && data.get(user_id)==Password) 
		{
			System.out.println("Login sucessfully!!!!");
			Select();
		}
		else 
		{
			System.out.println("Invalid Login!! Try again...");
				login();
		}
	}
	public void Select()
	{
		int ch;
		System.out.println("Choose any one option: ");
		System.out.println("1.Update profile and password\n2. Exam\n3.Logout\n");
		ch=s1.nextInt();
		switch(ch) 
		{
		case 1:
			data=update();
			Select();
			break;
		case 2:
			exam_que();
			Select();
			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("Invalid Option...");
		}
	}
	public HashMap<String,Integer> update()
	{
		String updated_user;
		int updated_pwd;
		System.out.println("-----------------Update Profile--------------");
		System.out.println("Enter user name");
		updated_user=s1.next();
		if(data.containsKey(updated_user)) 
		{
		System.out.println("Enter new password you to want to update to your profile");
		updated_pwd = s1.nextInt();
		data.replace(updated_user, updated_pwd);
		}
		else 
		{
			System.out.println("Username Not Found...");
		}
		return data;
	}
public void exam_que() 
{
	long examtime=System.currentTimeMillis();
	long endtime=examtime+30;
	int count=0;
	int ans,marks;
	
	while(System.currentTimeMillis()<endtime) 
	{
		System.out.println("Each question carries 10 marks");
		System.out.println("You have to answer 5 questions in 30 seconds");
		System.out.println("Start the exam..");
		System.out.println("\n\nQ1.\r\n"
				+ "Number of primitive data types in Java are?");
		System.out.println("\n1.6 \n 2.7 \n 3.8 \n 4.9\n");
		System.out.println("-->");
		ans=s1.nextInt();
		if(ans==3) 
		{
			count++;
		}
		System.out.println("\nWhat is the size of float and double in java?\r\n");
		System.out.println("1.32 and 64 \n 2.32 and 32 \n 3.64 and 64 \n  4.64 and 64\n");
		System.out.println("-->");
		ans=s1.nextInt();
		if(ans==1) 
		{
			count++;
		}
		System.out.println("\n\nAutomatic type conversion is possible in which of the possible cases?");
		System.out.println("1.Byte to int\n2.Int to long\n3.Long to int\n4. Short to int\n");
		System.out.println("-->");
		ans=s1.nextInt();
		if(ans==2) 
		{
			count++;
		}
		System.out.println("\n\nArrays in java are-");
		System.out.println("1.Object references\n2.Objects\n3. Primitive data type\n4. None\n");
		System.out.println("-->");
		ans=s1.nextInt();
		if(ans==2) 
		{
			count++;
		}
		System.out.println("\n\nWhen is the object created with new keyword?");
		System.out.println("1. At run time\n2.At compile time\n3.Depends on the code\n4. None\n");
		System.out.println("-->");
		ans=s1.nextInt();
		if(ans==1) 
		{
			count++;
		}
		break;
	}
	System.out.println("Exam Finished!!!");
	marks=count*10;
	System.out.println("You got"+" "+marks+"/50");	
}

public static void main (String[] args)
{
	online_exam Ex =new online_exam();
		Ex.login(); 
}
}